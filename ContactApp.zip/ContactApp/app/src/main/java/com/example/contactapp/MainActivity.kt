package com.example.contactapp

import android.app.AlertDialog
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var contacts: MutableList<String>
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sharedPreferences = getSharedPreferences("contacts", MODE_PRIVATE)

        contacts = loadContacts()
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, contacts)

        val listView: ListView = findViewById(R.id.list_view_contacts)
        listView.adapter = adapter

        val addButton: Button = findViewById(R.id.btn_add_contact)
        addButton.setOnClickListener { showContactDialog(null, -1) }

        listView.setOnItemClickListener { _, _, position, _ ->
            showContactDialog(contacts[position], position)
        }

        listView.setOnItemLongClickListener { _, _, position, _ ->

            AlertDialog.Builder(this)
                .setTitle("Delete Contact")
                .setMessage("Are you sure you want to delete this contact?")
                .setPositiveButton("Yes") { _, _ ->
                    deleteContact(position)
                }
                .setNegativeButton("No", null)
                .show()
            true
        }
    }

    private fun showContactDialog(contact: String?, position: Int) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_contact, null)
        val nameInput: EditText = dialogView.findViewById(R.id.edit_text_name)
        val phoneInput: EditText = dialogView.findViewById(R.id.edit_text_phone)

        if (contact != null) {
            val contactDetails = contact.split(" - ")
            nameInput.setText(contactDetails[0])
            phoneInput.setText(contactDetails[1])
        }

        AlertDialog.Builder(this)
            .setTitle(if (contact == null) "Add Contact" else "Edit Contact")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val name = nameInput.text.toString()
                val phone = phoneInput.text.toString()

                if (contact == null) {
                    addContact("$name - $phone")
                } else {
                    editContact(position, "$name - $phone")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun addContact(contact: String) {
        contacts.add(contact)
        saveContacts()
        adapter.notifyDataSetChanged()
    }

    private fun editContact(position: Int, contact: String) {
        contacts[position] = contact
        saveContacts()
        adapter.notifyDataSetChanged()
    }

    private fun deleteContact(position: Int) {
        contacts.removeAt(position)
        saveContacts()
        adapter.notifyDataSetChanged()
    }

    private fun saveContacts() {
        val editor = sharedPreferences.edit()
        val contactsString = contacts.joinToString(";") // Store contacts separated by ";"
        editor.putString("contact_list", contactsString)
        editor.apply()
    }

    private fun loadContacts(): MutableList<String> {
        val contactsString = sharedPreferences.getString("contact_list", "")
        return contactsString?.split(";")?.toMutableList() ?: mutableListOf()
    }
}


